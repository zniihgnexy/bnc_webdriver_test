# coding:utf-8
from selenium import webdriver
from time import sleep
from selenium.webdriver.common.by import By
import win32gui
import win32con
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

options = webdriver.ChromeOptions()
# 指定浏览器可执行程序路径
options.binary_location = 'C:/Users/xxzhen/AppData/Local/Programs/bncTuningTool/bncTuningTool.exe'

dr = webdriver.Chrome('C:/Users/xxzhen/python3.10/Scripts/chromedriver.exe',
                      options=options)  # 指定83版本chromedriver路径

sleep(3)  # 加载插件等需要等待
print(dr.page_source)  # 打印页面源码
# 点击设置
#dr.find_element('css selector', 'a[title="Manage"]').click()

def click(xpath):
    close_button = dr.find_element(By.XPATH, xpath)
    close_button.click()
    sleep(1)

def load_xml_file(file_path):
    # win32gui
    dialog = win32gui.FindWindow('#32770', u'Open')  # 对话框
    ComboBoxEx32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
    ComboBox = win32gui.FindWindowEx(ComboBoxEx32, 0, 'ComboBox', None)
    Edit = win32gui.FindWindowEx(ComboBox, 0, 'Edit', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
    button = win32gui.FindWindowEx(dialog, 0, 'Open', None)  # 确定按钮Button

    win32gui.SendMessage(Edit, win32con.WM_SETTEXT, None, file_path)  # 往输入框输入绝对地址

    sleep(5)
    win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)  # 按button

    sleep(5)

def export_xml_file(file_name):
    # win32gui
    dialog = win32gui.FindWindow('#32770', u'Open')  # 对话框
    ComboBoxEx32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
    ComboBox = win32gui.FindWindowEx(ComboBoxEx32, 0, 'ComboBox', None)
    Edit = win32gui.FindWindowEx(ComboBox, 0, 'File name', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
    button = win32gui.FindWindowEx(dialog, 0, 'Save', None)  # 确定按钮Button
    win32gui.SendMessage(Edit, win32con.WM_SETTEXT, None, 'result-2')  # 往输入框输入绝对地址
    win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)  # 按button
    sleep(5)

if __name__ == "__main__":


    #close_QRcode_frame()
    close_QRcode_frame='//*[@class="ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close"]'
    import_button='//*[@id="import_json"]'
    export_button='/ html / body / div[1] / button[2]'
    close_message_dialog='/html/body/div[6]/div[1]/button'
    rl_channel_correction_feature='/html/body/div[2]/div[2]/div/div[1]/label[1]/span[1]'
    high_pass_filter_feature='/html/body/div[2]/div[2]/div/div[1]/label[2]/span[1]'



    click(close_QRcode_frame)
    #import_button()
    click(import_button)
    load_xml_file('C:\\Users\\xxzhen\\PycharmProjects\\electron\\export.xml')
    #close_message_dialog()
    click(close_message_dialog)
    click(rl_channel_correction_feature)
    click(high_pass_filter_feature)
    click(export_button)
    export_xml_file('result-2')
    sleep(5)

    dr.quit()